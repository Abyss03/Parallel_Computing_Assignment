# Parallel Computing Assignment

# Assignmnet for importing historical weather conditions within Lincolnshire
